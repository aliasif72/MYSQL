const Expense=require('../model/expense');

exports.addExpense= (req,res,next)=>{
const category1=req.body.category;
const price1=req.body.amount;
const description1=req.body.description;
console.log(category1,price1,description1);
Expense.create({
    category:category1,
    amount:price1,
    description:description1
})
.then((result)=>res.status(200).json((result)))
.catch(err=>console.log(err));
}

exports.editExpense= async(req,res,next)=>{
   const id=req.params.Nid;
    const category1=req.body.category;
    const price1=req.body.amount;
    const description1=req.body.description; 
   await Expense.findByPk(id)   
    .then((data)=>
    {
         data.category=category1;
        data.amount=price1;
        data.description=description1;
        return data.save();
    })
    .then(result=>
        {
          res.status(200).json((result));
        })
    .catch(err=>console.log(err));
    }

 exports.getExpense = async(req,res,next)  =>{
  try{
   let result= await Expense.findAll();
    res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }
   

  exports.deleteExpense= (req,res,next)=>{
    const idd=req.params.Nid;    
                                                      //  Info.findByPk(idd)
            Expense.destroy({ where: { Id: idd} })   //.then(product=> 
                                                  //  {return product.destroy()})
                                                  //.then(result=>
                                                  //{console.log("deleted");
            .then((result)=>res.status(200).send('deleted'))
             .catch(err=>console.log(err));
             }