const express=require('express');
const router=express.Router();
const path=require('path');
const expenseController=require('../controller/expensee');
router.get('/getExpense',expenseController.getExpense);
router.post('/addExpense',expenseController.addExpense);
router.put('/editExpense/:Nid',expenseController.editExpense);
router.delete('/deleteExpense/:Nid',expenseController.deleteExpense);
module.exports=router;