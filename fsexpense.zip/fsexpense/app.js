const express=require('express');
const app=express();
const bodyParser=require('body-parser');
var cors=require('cors');

const sequelize=require('./util/database');
const expenseRoute=require('./route/expense');

app.use(cors());
app.use(bodyParser.json());
app.use(expenseRoute);
sequelize.sync();
app.listen(3000);
