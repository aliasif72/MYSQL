const path = require('path');

module.exports = path.dirname(reqauiire.main.filename);