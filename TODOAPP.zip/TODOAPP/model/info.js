const Sequelize =require('sequelize');
const sequelize=require('../util/database');
const TODO= sequelize.define(('todo'),{
    Id:{
     type: Sequelize.INTEGER,
     autoIncrement: true,
     allowNull:false,
     primaryKey:true
    },
    name:{
        type: Sequelize.STRING,
        allowNull:false,
        unique:true    
    },
    description:{
        type:Sequelize.STRING,
        allowNull:false,
           },
           status:
           {
            type:Sequelize.STRING,
            allowNull:false,
                       }
        });
    module.exports=TODO;