const Expense=require('../model/expense');
const jwt=require('jsonwebtoken');
const User=require('../model/user');
const sequelize = require('../util/database');

exports.addExpense= async (req,res,next)=>{
  const t= await sequelize.transaction();
  const { category, amount, description } = req.body;
const total=Number(req.user.amounts)+Number(amount);
try
{
  await User.update(
  {
    amounts:total }, {
      where: { id:req.user.id},
    transaction : t}) 
 const result=await req.user.createExpense({
category,
amount,
description},
{transaction : t}
  )

//                                          Expense.create({
//                                           category,
//                                             amount,
//                                           description,      
//                                           user1Id:req.user.Id
//                                                })
  await t.commit();
  res.status(200).json(result);
}
catch(error)
  { await t.rollback();
    console.log(err);
}
}
exports.getExpenseByPk = async(req,res,next)  =>{
  try{
    const id=req.header('authorization');
     let result= await Expense.findByPk(id);
       res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }

exports.editExpense= async(req,res,next)=>{
   const ide=req.params.Nid;
    const category=req.body.category;
    const price=req.body.amount;
    const description=req.body.description; 
   await Expense.findByPk(ide)   
    .then((data)=>
    {
         data.category=category;
        data.amount=price;
        data.description=description;
        return data.save();
    })
    .then(result=>
        {
          res.status(200).json((result));
        })
    .catch(err=>console.log(err));
    }

 exports.getExpense = async(req,res,next)  =>{
  try{
       let result=await req.user.getExpenses()
       res.status(200).json(result); 
     }
    catch(err)
         {
          console.log(err);
         }
            }
   
  exports.deleteExpense= async(req,res,next)=>{
    const idd=req.params.Nid;    
    const t= await sequelize.transaction(); 
    try{
        const exp = await Expense.findByPk(idd); 
       const newamounts= Number(req.user.amounts)-Number(exp.amount);
          await User.update({
          amounts : newamounts},
         { where: { id:req.user.id },
            transaction : t
               })                   //  Info.findByPk(idd)
            Expense.destroy({ where: { Id: idd, user1Id: req.user.id} })   //.then(product=> 
                                                  //  {return product.destroy()})
                                                  //.then(result=>
                                                  //{console.log("deleted");
          await t.commit();
            res.status(200).send('deleted');
              }
             catch(error)
             {
              await t.rollback();
              console.log(err);
             }
            }